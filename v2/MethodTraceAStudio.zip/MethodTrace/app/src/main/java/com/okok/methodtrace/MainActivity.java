package com.okok.methodtrace;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

class MethodComparator implements Comparator<String[]> {

    // override the compare() method
    public int compare(String[] s1, String[] s2)
    {
        if (Long.parseLong(s1[2]) == Long.parseLong(s2[2]))
            return 0;
        else if (Long.parseLong(s1[2]) > Long.parseLong(s2[2]))
            return -1;
        else
            return 1;
    }
}

public class MainActivity extends AppCompatActivity {
    String fpath = "/sdcard/trace/trace.txt";
    String lckpath = "/sdcard/trace/lock";
    String curFindName;
    String curFindInvCnt;
    ArrayList<String> curFindOpType;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // https://guides.codepath.com/android/using-the-recyclerview
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView rv = findViewById(R.id.rv);
        getPermission();

        rv.setAdapter(new MethodsAdapter(getData(null, null, null)));
        rv.setLayoutManager(new LinearLayoutManager(this));

        Button searchBtn = findViewById(R.id.buttonSearch);
        searchBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EditText edtFindName = findViewById(R.id.editTextTextFindName);
                EditText edtFindInvCnt = findViewById(R.id.editTextTextFindInvCnt);

                curFindName = edtFindName.getText().toString();
                if (curFindName.isEmpty()) curFindName = null;
                curFindInvCnt = edtFindInvCnt.getText().toString();
                if (curFindInvCnt.isEmpty()) curFindInvCnt = null;
                rv.setAdapter(new MethodsAdapter(getData(curFindName, curFindInvCnt, curFindOpType)));
            }
        });

        Button searchByOpTypeBtn = findViewById(R.id.buttonShowByOpType);
        searchByOpTypeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Search by operation types");
                builder.setMessage("1 = strings\n2 = cond tests\n3 = arrays\n4 = setTexts\n5 = URLs\n6 = math operations\n\n(Separate types with spaces, they are OR relationship)");

                // Set up the input
                EditText input = new EditText(MainActivity.this);
                // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
                builder.setView(input);

                // Set up the buttons
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        curFindOpType = new ArrayList<>(Arrays.asList(input.getText().toString().split(" ")));
                        if (curFindOpType.size() == 1 && curFindOpType.get(0).isEmpty()) {
                            curFindOpType = null;
                            searchByOpTypeBtn.setTextColor(Color.WHITE);
                        } else
                            searchByOpTypeBtn.setTextColor(Color.RED);
                        rv.setAdapter(new MethodsAdapter(getData(curFindName, curFindName, curFindOpType)));
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        Button refreshBtn = findViewById(R.id.buttonRefresh);
        refreshBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                rv.setAdapter(new MethodsAdapter(getData(null, null, null)));
                curFindInvCnt = null;
                curFindName = null;
                curFindOpType = null;
                searchByOpTypeBtn.setTextColor(Color.WHITE);
            }
        });

        Button clearBtn = findViewById(R.id.buttonClear);
        clearBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                try {
                    File file = new File(fpath);
                    BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                    writer.write("");
                    writer.flush();
                    writer.close();

                    rv.setAdapter(new MethodsAdapter(getData(null, null, null)));
                    Toast.makeText(MainActivity.this, "Cleared", Toast.LENGTH_SHORT).show();
                    curFindInvCnt = null;
                    curFindName = null;
                    curFindOpType = null;
                    searchByOpTypeBtn.setTextColor(Color.WHITE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Can't read '/sdcard/trace/trace.txt' properly. Please fix it.", Toast.LENGTH_LONG).show();
                }
            }
        });

        Button lockTraceBtn = findViewById(R.id.buttonLockTrace);
        lockTraceBtn.setText(isTraceLocked()? "🔒" : "🔓");
        lockTraceBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (isTraceLocked()) {
                    if (new File(lckpath).delete()) {
                        Toast.makeText(MainActivity.this, "Unlocked trace.", Toast.LENGTH_SHORT).show();
                        lockTraceBtn.setText("🔓");
                    } else {
                        Toast.makeText(MainActivity.this, "Could not unlock trace.", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    try {
                        Toast.makeText(MainActivity.this, new File(lckpath).createNewFile() ? "Locked trace." : "Could not lock trace.", Toast.LENGTH_SHORT).show();
                        lockTraceBtn.setText("🔒");
                    } catch (IOException e) {
                        Toast.makeText(MainActivity.this, "Could not lock trace.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private boolean isTraceLocked() {
        return new File(lckpath).exists();
    }

    private void getPermission() {
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
    }

    private ArrayList<String[]> getData(String findName, String findInvCnt, ArrayList<String> findType) {
        // findType: 1,2,3,4,5,6 OR 1,2,3
        // 1 = strings, 2 = cond tests, 3 = arrays, 4 = setTexts, 5 = URLs, 6 = math operations
        ArrayList<String[]> arr = new ArrayList<>();
        try {
            File file = new File(fpath);
            FileInputStream fis = new FileInputStream(file);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));

            String line;
            while ((line = br.readLine()) != null) {
                String[] dat = line.split("::");
                if (findName != null && !dat[0].toLowerCase().contains(findName.toLowerCase()) || findInvCnt != null && !dat[3].contains(findInvCnt))
                    continue;

                if (findType != null && !findType.isEmpty()) {
                    String[] methodAnalysis = dat[1].split(",");
                    boolean found = false;

                    for (int i = 0; i < methodAnalysis.length; i++) {
                        if (Integer.parseInt(methodAnalysis[i]) > 0 && findType.contains(String.valueOf(i+1))) {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        continue;
                }

                arr.add(dat);
            }

            br.close();
            fis.close();

        }catch (Exception e) {
            Toast.makeText(this, "Can't read '/sdcard/trace/trace.txt' properly. Please fix it.", Toast.LENGTH_LONG).show();
        }

        Collections.sort(arr, new MethodComparator());
        if (!arr.isEmpty())
            Toast.makeText(this, "Totally " + arr.size() + " methods", Toast.LENGTH_SHORT).show();
        return arr;
    }
}