package com.okok.methodtrace;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MethodsAdapter extends RecyclerView.Adapter<MethodsAdapter.ViewHolder> {
    private List<String[]> m_oMethods;

    public MethodsAdapter(List<String[]> methods) {
        m_oMethods = methods;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout (the card view)
        View contactView = inflater.inflate(R.layout.card, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(contactView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Get the data model based on position
        String[] data = m_oMethods.get(position);
        String description = String.format("Invoked %s times (nano: %s)", position == 0 ? ">=" + data[3] : data[3], data[2]);
        String[] methodAnalysis = data[1].split(",");
        if (!data[1].equals("0,0,0,0,0,0")) {
            description += System.lineSeparator() + "[";

            if (Integer.parseInt(methodAnalysis[0]) > 0) {
                description += methodAnalysis[0] + " string(s) ";
            }

            if (Integer.parseInt(methodAnalysis[1]) > 0) {
                description += methodAnalysis[1] + " cond-test(s) ";
            }

            if (Integer.parseInt(methodAnalysis[2]) > 0) {
                description += methodAnalysis[2] + " array(s) ";
            }

            if (Integer.parseInt(methodAnalysis[3]) > 0) {
                description += methodAnalysis[3] + " setText(s) ";
            }

            if (Integer.parseInt(methodAnalysis[4]) > 0) {
                description += methodAnalysis[4] + " URL(s) ";
            }

            if (Integer.parseInt(methodAnalysis[5]) > 0) {
                description += methodAnalysis[5] + " math-operations ";
            }

            description += "]";
        }

        // Set item views based on your views and data model
        TextView methodName = holder.methodName;
        TextView methodDesc = holder.methodDesc;
        methodName.setText(data[0]);
        methodDesc.setText(description);
    }

    @Override
    public int getItemCount() {
        return m_oMethods.size();
    }

    // Provide a direct reference to each of the views within a data item
    // Used to cache the views within the item layout for fast access
    public class ViewHolder extends RecyclerView.ViewHolder {
        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        public TextView methodName;
        public TextView methodDesc;

        // We also create a constructor that accepts the entire item row
        // and does the view lookups to find each subview
        public ViewHolder(View itemView) {
            // Stores the itemView in a public final member variable that can be used
            // to access the context from any ViewHolder instance.
            super(itemView);

            methodName = itemView.findViewById(R.id.method_name);
            methodDesc = itemView.findViewById(R.id.method_desc);
        }
    }
}